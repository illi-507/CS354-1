
int negate(int);
int test_negate(int);
int isNegative(int);
int test_isNegative(int);
int fitsBits(int, int);
int test_fitsBits(int, int);
int isNotEqual(int, int);
int test_isNotEqual(int, int);
int isEqual(int, int);
int test_isEqual(int, int);
int getByte(int, int);
int test_getByte(int, int);
int isPositive(int);
int test_isPositive(int);
int sign(int);
int test_sign(int);
